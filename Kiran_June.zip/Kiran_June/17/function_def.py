#************Functional Programming*********************
#Function Defination
def add():
    n1=eval(input("enter num1: "))
    n2=eval(input("enter num2: "))
    print(n1+n2)
add()

def sub():
    n1=eval(input("enter num1: "))
    n2=eval(input("enter num2: "))
    print(n1-n2)
sub()

