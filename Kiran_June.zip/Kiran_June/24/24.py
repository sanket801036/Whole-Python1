# """
# #WAp to fund prime
# def is_prime(num):
#     for n in range(1,num):
#         if num%n == 0:
#             return 'not prime'
#     else:
#         return 'prime'
# """
# #Wap to check palindrome or not

# def is_palindrome(word):
#     if str(word) == str(word)[::-1]:
#         return 'palindrome'
#     else:
#         return 'not palindrome'
# print(is_palindrome("madam"))

# def is_palindrome(word):
#     r=word[::-1]
#     if word==r:
#         return True
#     else:
#         return False
# print(is_palindrome("sanket"))

#Wap to print square of any number
# def square(a):
#     return a**2
    
#  sq=lambda   
# List Programs

# 1) Write a python program to sum all the items in a list.
# l=[1,2,3,4,56,64,128]
# print(sum(l))

# 2) Write a Python program to multiply all the items in a list.
# l=[1,2,3,4,56,64,128]
# p=1
# for i in l:
#     p*=i

# 3) Write a Python program to get the smallest number from a list.
# l = [1, 2, 3, 4, 56, 64, 128]
# p = l[0]
# for i in l:
#     if i<p:
#         p=i
# print(p)
# print()

# l = [1, 2, 3, 4, 56, 64, 128]
# p = l[0]
# for i in l:
#     if i>p:
#         p=i
# print(p)
# print()

# l = [1, 2, 3, 4, 56, 64, 128]
# l1=sort(l)
# print(l1)
# p = l1[0]
# for i in l1:
#     if i>p:
#         p=i

# 4) Write a Python program to count the number of strings from a given list of strings. The string length is 2 or more and the first and last characters are the same. Sample List, ['abc', 'xyz', 'aba', '1221'] Expected Result :2 Write a Python program to get the largest number from a list.
# def match_wo
