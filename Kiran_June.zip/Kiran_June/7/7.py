#1)Flow Control Statement
#a.Conditional 
#b.Iterative statement
#c.transfer statement

#a.Conditional statement
# if statement
#Syntx-->
# if condition:
#   body if
#   statement
#   code
age=int(input("enter age: "))
if age>18:
    print("You are eligible for voting")#enter age: 19

age=int(input("enter age: "))
if age>18:
    print("You are eligible for voting")#gives no output
  
# if else statement 
# if elif else statement
#3)if statement

#1)Wap to Check Positive number
num = eval(input("Enter num: "))
if num%2==0:
    print("positive number")

#2)Wap to check even number
num = eval(input("Enter num: "))
if num//2:
    print("Enter number is even")
#3)Wap to check negative
num = eval(input("Enter num: "))
if num < 0:
    print("Enter number is negative")

#4)Wap to check odd number
num = eval(input("Enter num: "))
if num % 2!= 0:
    print("Enter number is odd")

#l=[11,-22,33,-44,55,66]
# Wap to print only positive numbers fro given 
l=[11,-22,33,-44,55,66]
for num in l:
    if num>0:
        print(num)
#O/p
# 11
# 33
# 55
# 66

#OR

l = [11, -22, 33, -44, 55, 66]
p = [num for num in l if num > 0]
print(p) #[11, 33, 55, 66]

# Wap to print only positive numbers fro given 
l=[11,-22,33,-44,55,66]
for num in l:
    if num<0:
        print(num)
#O/p:-
# -22
# -44

#OR

l = [11, -22, 33, -44, 55, 66]
p = [num for num in l if num < 0]
print(p)#[-22, -44]

#Wap to print only even numbers fro given list
l = [11, -22, 33, -44, 55, 66]
for num in l:
    if num in l:
        if num%2==0:
            print(num)

# O/P:-
# -22
# -44
# 66

#OR:-

l = [11, -22, 33, -44, 55, 66]
p = [num for num in l if num % 2 == 0]
print(p) #[-22, 66]


#Wap to print only odd numbers fro given list
i = [11, -22, 33, -44, 55, 66]
even_numbers = [num for num in i if num % 2 == 0]
print(even_numbers)


employee={"raj":22000,"vijay":51000,"jayesh":40000,"pavan":90000}
for i in employee:
    if employee[i]>50000:
        print(i)
#O/P:-
# vijay
# pavan

oneplus={"ce3":22000,"ce2":19000,"c24":24000}
for i in oneplus:
    if oneplus[i]>5000:
        print(i)

l={11,22,33,44}
for i in l:
    print(i)
s="rahul"
d={"name":"rahul","age":"pune"}
    
