




Laptop = {"lenovo":{"lenovo_V15":{"Generation":"i3","Ram":"4gb","SSD":"512GB","Cores":6},"Lenovo_V14":{"Generation":"i5","Ram":"8gb","SSD":"1120GB","Cores":8}},"HP":{"HP_Chromebook":{"Generation":"i7","Ram":"12gb","SSD":"245GB","Cores":4},"HP_Pavillion":{"Generation":"i5","Ram":"18gb","SSD":"1125GB","Cores":12}}}


