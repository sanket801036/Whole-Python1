# Transfer statements in Python are used to control the flow of execution within loops and functions. The primary transfer statements are `break`, `continue`, and `return`. Here are 20 practical interview questions and answers related to these statements:

# ### 1. **What is the purpose of the `break` statement in Python?**
# - **Explanation:** `break` exits the nearest enclosing loop prematurely.
#     for i in range(10):
#         if i == 5:
#             break
#         print(i)  # Outputs 0, 1, 2, 3, 4

# ### 2. **How does the `continue` statement work in Python?**
# - **Explanation:** `continue` skips the rest of the code inside the loop for the current iteration and proceeds to the next iteration.
#     for i in range(10):
#         if i % 2 == 0:
#             continue
#         print(i)  # Outputs 1, 3, 5, 7, 9

# ### 3. **What is the function of the `return` statement in a Python function?**
# - **Explanation:** `return` exits a function and optionally passes a value back to the caller.
#     def add(a, b):
#         return a + b
#     result = add(3, 4)
#     print(result)  # Output: 7

# ### 4. **How can you use `break` to exit a loop based on user input?**
# - **Explanation:** Use `break` to exit a loop when a specific user input is encountered.
#     while True:
#         user_input = input("Type 'exit' to stop: ")
#         if user_input == 'exit':
#             break

# ### 5. **How do you use `continue` to skip certain iterations in a loop?**
# - **Explanation:** Use `continue` to skip over specific iterations based on a condition.
#     for i in range(10):
#         if i % 2 == 0:
#             continue
#         print(i)  # Outputs odd numbers from 1 to 9

# ### 6. **How can `return` be used to exit a function early?**
# - **Explanation:** Use `return` to exit a function before it reaches the end, often based on a condition.


#     def process_value(value):
#         if value < 0:
#             return "Negative value"
#         # Process positive value
#         return "Processed value"

#     print(process_value(-1))  # Output: Negative value


# ### 7. **How do `break`, `continue`, and `return` interact in nested loops?**
# - **Explanation:** `break` and `continue` only affect the nearest enclosing loop, while `return` affects the function's execution.

#     def nested_loop_example():
#         for i in range(3):
#             for j in range(3):
#                 if j == 1:
#                     break  # Breaks inner loop
#                 print(i, j)
#         return "Done"

#     nested_loop_example()


# ### 8. **How can you use `break` to terminate a `while` loop?**
# - **Explanation:** Use `break` to exit a `while` loop based on a condition.

#     ```python
#     count = 0
#     while True:
#         count += 1
#         if count > 5:
#             break
#         print(count)  # Outputs numbers from 1 to 5
#     ```

# ### 9. **How does `continue` work in a `while` loop?**
# - **Explanation:** `continue` skips the rest of the loop body and starts the next iteration.

#     ```python
#     count = 0
#     while count < 10:
#         count += 1
#         if count % 2 == 0:
#             continue
#         print(count)  # Outputs odd numbers from 1 to 9
#     ```

# ### 10. **How can you use `return` to return multiple values from a function?**
# - **Explanation:** Use `return` to return a tuple of values.

#     ```python
#     def get_stats(numbers):
#         total = sum(numbers)
#         count = len(numbers)
#         return total, count

#     total, count = get_stats([1, 2, 3, 4])
#     print(total, count)  # Output: 10 4
#     ```

# ### 11. **How can `break` be used in a loop with `else` clause?**
# - **Explanation:** If `break` is executed, the `else` block will not run.

#     ```python
#     for i in range(5):
#         if i == 3:
#             break
#     else:
#         print("Loop completed")
#     ```

# ### 12. **How does `continue` affect the `else` clause of a loop?**
# - **Explanation:** `continue` will skip the rest of the loop body but does not affect the `else` clause.

#     ```python
#     for i in range(5):
#         if i % 2 == 0:
#             continue
#         print(i)
#     else:
#         print("Loop completed")  # This will be printed
#     ```

# ### 13. **How can `return` be used to exit from nested functions?**
# - **Explanation:** `return` will exit only from the current function, not from all nested functions.

#     ```python
#     def outer_function():
#         def inner_function():
#             return "Returned from inner"
#         return inner_function()

#     print(outer_function())  # Output: Returned from inner
#     ```

# ### 14. **How can you use `break` to manage infinite loops?**
# - **Explanation:** `break` can be used to exit an infinite `while` loop based on a condition.

#     ```python
#     while True:
#         user_input = input("Type 'stop' to exit: ")
#         if user_input == 'stop':
#             break
#     ```

# ### 15. **How can `continue` be used to skip even numbers in a `for` loop?**
# - **Explanation:** Use `continue` to skip over even numbers.

#     ```python
#     for i in range(10):
#         if i % 2 == 0:
#             continue
#         print(i)  # Outputs odd numbers from 1 to 9
#     ```

# ### 16. **How do you use `return` in a recursive function to manage recursion?**
# - **Explanation:** `return` can be used to end a recursive function call.

#     ```python
#     def factorial(n):
#         if n == 0:
#             return 1
#         else:
#             return n * factorial(n - 1)

#     print(factorial(5))  # Output: 120
#     ```

# ### 17. **How can you use `break` to exit a loop based on a condition from a list of items?**
# - **Explanation:** Use `break` to exit the loop when a specific item is found.

#     ```python
#     items = ['apple', 'banana', 'cherry']
#     for item in items:
#         if item == 'banana':
#             break
#         print(item)  # Outputs 'apple'
#     ```

# ### 18. **How does `continue` handle exceptions in a loop?**
# - **Explanation:** `continue` does not handle exceptions; exceptions need to be managed with `try-except`.

#     ```python
#     for i in range(5):
#         try:
#             if i == 2:
#                 raise ValueError("Error")
#         except ValueError:
#             continue
#         print(i)  # Outputs 0, 1, 3, 4
#     ```

# ### 19. **How can `return` be used to set default values in a function?**
# - **Explanation:** `return` can be used to provide default values when certain conditions are not met.

#     ```python
#     def get_value(value=None):
#         if value is None:
#             return "Default value"
#         return value

#     print(get_value())  # Output: Default value
#     ```

# ### 20. **How do `break` and `return` differ in their effect on loop execution?**
# - **Explanation:** `break` exits the loop, while `return` exits the function containing the loop.

#     ```python
#     def loop_with_break():
#         for i in range(5):
#             if i == 3:
#                 break
#             print(f"Break loop: {i}")

#     def loop_with_return():
#         for i in range(5):
#             if i == 3:
#                 return
#             print(f"Return loop: {i}")

#     loop_with_break()  # Output: Break loop: 0, 1, 2
#     loop_with_return()  # Output: Return loop: 0, 1, 2
#     ```

# These questions cover practical uses of transfer statements (`break`, `continue`, `return`) in Python, demonstrating their application in loops and functions.