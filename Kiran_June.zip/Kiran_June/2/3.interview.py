"""
1)what is dict?
It is  ordered,mutable,heterogeneous collection of elements where data is represented in the form of key and value.

2)How to access data from dict
tata={"nexon":{"nexon1":{"price":800000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6},"nexon2":{"price":600000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6}},"neno":{"neno1":{"price":700000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6},"neno2":{"price":900000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6}}}

print(tata["neno"]["neno1"])
print(tata["neno"]["neno1"]["price"])
print(tata["nexon"]["nexon1"]["Engine"])
#Or
tata={"nexon":{"nexon1":{"price":800000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6},"nexon2":{"price":600000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6}},"neno":{"neno1":{"price":700000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6},"neno2":{"price":900000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6}}}

print(tata.get("neno"))

#How to update data?
tata={"nexon":{"nexon1":{"price":800000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6},"nexon2":{"price":600000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6}},"neno":{"neno1":{"price":700000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6},"neno2":{"price":900000,"Engine":"2000cc","Fuel":"Petrol","Cylenders":6}}}
tata["neno"]["neno1"]["Engine"]="500cc"
print(tata)




"""